package com.example;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AppointmentTest{

    private static final String JDBCURL = "jdbc:postgresql://192.168.2.3:5432/kowsik";
    private static final String USER = "glace";
    private static final String DBPASSWORD = "glacenxt";

    public static void main(String[] args) {
    	AppointmentTest  dbTest = new AppointmentTest();
        dbTest.testDatabaseConnection("tsd ", "sd");
    }

    public void testDatabaseConnection(String name, String phone) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
         
            Class.forName("org.postgresql.Driver");

           
            connection = DriverManager.getConnection(JDBCURL, USER, DBPASSWORD);
            System.out.println("Database connection established.");

            String query = "INSERT INTO Appointments (name, phone) VALUES (?, ?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, phone);

            // Execute the update
            int rows = statement.executeUpdate();

            if (rows > 0) {
                System.out.println("User  added to the database successfully.");
            } else {
                System.out.println("There was an error adding the user.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL error: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("JDBC Driver not found: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("General error: " + e.getMessage());
        } finally {
            // Close resources
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}