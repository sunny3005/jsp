package com.example;
import org.json.JSONObject;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

/**
 * Servlet implementation class DeleteAppointment
 */
@WebServlet("/DeleteAppointment")
public class DeleteAppointment extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public DeleteAppointment() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = request.getReader().readLine()) != null) {
            sb.append(line);
        }

        JSONObject jsonData = new JSONObject(sb.toString());
        int pid = jsonData.getInt("pid");  // Use getInt to get the integer value of pid

        Connection connection = null;
        PreparedStatement statement = null;
        final String JDBCURL = "jdbc:postgresql://192.168.2.3:5432/kowsik";
        final String USER = "glace";
        final String DBPASSWORD = "glacenxt";

        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(JDBCURL, USER, DBPASSWORD);
            String query = "DELETE FROM appointments WHERE pid=?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, pid);  // Set pid as an integer
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.getWriter().write("{\"message\":\"Deleted successfully\"}");
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("{\"message\":\"Appointment not found\"}");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"message\":\"Error occurred\"}");
        } finally {
            try {
                 connection.close();
                 statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
