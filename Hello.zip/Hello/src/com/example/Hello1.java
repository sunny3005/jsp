package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import org.json.JSONObject;

@WebServlet("/Hello1")
public class Hello1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        final String JDBCURL = "jdbc:postgresql://192.168.2.3:5432/kowsik";
        final String USER = "glace";
        final String DBPASSWORD = "glacenxt";

        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = request.getReader().readLine()) != null) {
            sb.append(line);
        }
        
        JSONObject jsonData = new JSONObject(sb.toString());

        String name = jsonData.getString("name");
        String phone = jsonData.getString("phone");
        String address = jsonData.getString("address");
        String doctor= jsonData.getString("doctor");
        String problem = jsonData.getString("problem");
        String timeslot = jsonData.getString("timeslot");
        String req=jsonData.getString("req");

        Connection connection = null;
        PreparedStatement statement = null;

        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(JDBCURL, USER, DBPASSWORD);
            System.out.println("Database connection established.");

            String query = "INSERT INTO Appointments (name, phone, address, doctor, problem, timeslot,req) VALUES (?, ?, ?, ?, ?, ?,?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, phone);
            statement.setString(3, address);
            statement.setString(4, doctor);
            statement.setString(5, problem);
            statement.setString(6, timeslot);
            statement.setString(7,req);

            int rows = statement.executeUpdate();

            if (rows > 0) {
                response.setStatus(HttpServletResponse.SC_OK);
               response.getWriter().write("{\"message\":\"Appointment booked successfully\"}");
               System.out.println("Database.");
      
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"message\":\"Failed to book appointment\"}");
                System.out.println("Database.");
            }


        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"message\":\"Database error: " + e.getMessage() + "\"}");
            System.out.println("Database.");
        } finally {
            try {
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Database.");
        
        

    }
    
}
