package com.example;

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

@WebServlet("/UpdateDetails")
public class UpdateDetails extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String doctor = request.getParameter("doctor");
        String problem = request.getParameter("problem");
        String timeslot = request.getParameter("timeslot");

        Connection connection = null;
        PreparedStatement statement = null;

        final String JDBCURL = "jdbc:postgresql://192.168.2.3:5432/kowsik";
        final String USER = "glace";
        final String DBPASSWORD = "glacenxt";
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = request.getReader().readLine()) != null) {
            sb.append(line);
        }
        
        JSONObject jsonData = new JSONObject(sb.toString());
        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(JDBCURL, USER, DBPASSWORD);

            String query = "UPDATE Appointments SET phone = ?, address = ?, doctor = ?, problem = ?, timeslot = ? WHERE name = ?";
            statement = connection.prepareStatement(query);
            statement.setString(1, phone);
            statement.setString(2, address);
            statement.setString(3, doctor);
            statement.setString(4, problem);
            statement.setString(5, timeslot);
            statement.setString(6, name);

            int rows = statement.executeUpdate();

            if (rows > 0) {
              
                request.setAttribute("name", name);
                request.setAttribute("phone", phone);
                request.setAttribute("address", address);
                request.setAttribute("doctor", doctor);
                request.setAttribute("problem", problem);
                request.setAttribute("timeslot", timeslot);
                RequestDispatcher dispatcher = request.getRequestDispatcher("rece.jsp");
                dispatcher.forward(request, response);
                response.setStatus(HttpServletResponse.SC_OK);
                   response.getWriter().write("{\"message\":\"updated successfully\"}");
                   System.out.println("Database.");
          
                 
                    
                
            } else {
            	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"message\":\"Failed to update\"}");
                
                
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }

}


