package com.example;

public @interface override {

}
