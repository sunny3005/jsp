package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "login_details")
public class LoginModel {
	
	
	    private String username;
	    @Id
	    
	    private String phoneNumber;

	    public LoginModel(String username, String phoneNumber) {
			super();
			this.username = username;
			this.phoneNumber = phoneNumber;
		}

		
	    public LoginModel() {
			
		}


		public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }

	    public String getPhoneNumber() {
	        return phoneNumber;
	    }

	    public void setPhoneNumber(String phoneNumber) {
	        this.phoneNumber = phoneNumber;
	    }
	}

