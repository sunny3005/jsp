package com.example.demo;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    @Autowired
    private LoginRepository loginRepository;

    public LoginModel createPatient(LoginModel loginModel) {
        // The ID will be auto-generated due to @GeneratedValue
        return loginRepository.save(loginModel);
    }
}

