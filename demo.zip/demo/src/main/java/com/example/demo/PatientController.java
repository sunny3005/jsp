package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/add")
public class PatientController {

    @Autowired
    private PatientService ps;  // Keep the variable consistent

    // Method to save a patient
    @PostMapping
    public ResponseEntity<PatientModel> savePatient(@RequestBody PatientModel patient) {
        // Creating the patient using the service
        PatientModel savedPatient = ps.CreatePatient(patient); 
        return ResponseEntity.ok(savedPatient);  
    }

    
}
