package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PatientRepository extends JpaRepository<PatientModel, Long> {
    // This will automatically provide delete functionality by phoneNumber
    void deleteByPhoneNumber(Long phoneNumber);
}
