package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PatientService {
	
	@Autowired
	private PatientRepository pr;
	public PatientModel CreatePatient(PatientModel patient) {
		return pr.save(patient);
	}
	public void deletePatientByPhoneNumber(Long phoneNumber) {
        pr.deleteByPhoneNumber(phoneNumber);  // Assuming you have this method in your repository
    }

}
